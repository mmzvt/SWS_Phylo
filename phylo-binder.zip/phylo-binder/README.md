# From proteins to a phylogenetic tree (Binder teaching session)

[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/YOUR-GITHUB-USER/YOUR-REPO/HEAD?urlpath=lab%2Ftree%2Fphylogeny_workflow.ipynb)

Students start from a set of proteins, find a core gene with `hmmsearch`, combine the hits with reference sequences, align with MAFFT, trim with trimAl, and download the trimmed alignment to build a tree on a web server.

## What is in this repository

```
binder/environment.yml      software Binder installs (HMMER, MAFFT, trimAl, seqkit, FastTree, Python)
phylogeny_workflow.ipynb    the student notebook
data/                       YOUR input files go here (see data/README.md)
```

The notebook writes everything it makes to a `results/` folder.

## Setting up (instructor)

1. Put three files in `data/`, with exactly these names: `query_proteins.faa`, `core_gene.hmm`, `references.faa`. See `data/README.md` for the details.
2. Push the repository to GitHub. It must be public for mybinder.org.
3. In the badge link at the top of this file, replace `YOUR-GITHUB-USER/YOUR-REPO` with your own. The `urlpath` part opens the notebook directly in JupyterLab.
4. Click the badge once, a day before class. The first launch builds the environment and can take 5 to 15 minutes. Later launches reuse that build and start much faster.
5. Run every cell once to check that the whole workflow works with your data.

**Do not push changes on the day of class.** Every new commit triggers a fresh build, and the first students to click will wait for it.

## Limits of mybinder.org to plan around

- mybinder.org is a free service run by volunteers, with limited capacity. Its operators have asked heavy course users to consider other options, so a large class may see slow or failed launches.
- Each session has little memory (about 1 to 2 GB) and roughly one CPU. That is enough for this workflow with a few hundred proteins and a reference set of tens of sequences.
- A session shuts down after about 10 minutes without activity, and all files in it are lost. Students should download their trimmed alignment as soon as they have it.

**Backup if Binder is slow on the day:** the same environment file works on any laptop with conda or mamba:

```
conda env create -f binder/environment.yml
conda activate phylo-teaching
jupyter lab
```

## Tree-building web servers (status checked November 2026)

Ask students to upload `results/combined.trimmed.faa`, set the data type to protein, let the server pick the model, and turn on branch support.

- **Phylogeny.fr** (https://www.phylogeny.fr). Relaunched in 2026 with a new interface. Offers IQ-TREE, RAxML-NG, FastTree, and PhyML, plus built-in alignment and tree viewers. Limits: 200 sequences and 2,000 amino acids per sequence, FASTA input only. Results are kept for about one week. The old interface is at https://old.phylogeny.fr.
- **IQ-TREE web server, Vienna** (http://iqtree.cibiv.univie.ac.at). Was offline for a rebuild through much of 2025 and 2026. In September 2026 the maintainers said it was about to return and asked instructors to email Heiko Schmidt (heiko.schmidt AT univie.ac.at) with their course dates. Check that it works before class.
- **IQ-TREE web server, Los Alamos** (https://www.hiv.lanl.gov/content/sequence/IQTREE/iqtree.html). Suggested by the IQ-TREE team as an alternative while the Vienna server was down.
- **NGPhylogeny.fr** (https://ngphylogeny.fr). Runs on the Galaxy server at Institut Pasteur. Has one-click workflows and individual tools (PhyML, FastTree, and others).
- **Not CIPRES.** It stopped accepting jobs on 30 June 2026.

If no server is available, the notebook has a backup cell that builds a quick FastTree tree inside the Binder session, and a cell that draws any Newick tree with the students' sequences highlighted.
